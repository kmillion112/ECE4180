#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <string>

#include "DebounceIn.h"
#include "HTU21D.h"
#include "LSM9DS1.h"
#include "MPL3115A2.h"
#include "MPL3115A2/MPL3115A2.h"
#include "PinDetect.h"
#include "SDFileSystem.h"
#include "mbed.h"
#include "rtos.h"
#include "uLCD_4DGL.h"
#include "wave_player.h"

#define MPL3115A2_I2C_ADDRESS (0x60);
#define PI 3.14159
#define DECLINATION -4.94  // Declination (degrees) in Atlanta,GA.

SDFileSystem sd(p5, p6, p7, p8, "sd");  // SD card

AnalogOut DACout(p18);

wave_player waver(&DACout);

// connected modules, pc included to help with debugging purposes for any device
// upgrades
Serial pc(USBTX, USBRX);
Serial blue(p28, p27);
uLCD_4DGL uLCD(p13, p14, p11);

// Hardware Sensors
HTU21D temphumid(p9, p10);
LSM9DS1 IMU(p9, p10, 0xD6, 0x3C);
MPL3115A2 mpl(p9, p10, (0x60));
AnalogIn lightSensor(p20);

// mbed led output
BusOut myled(LED1, LED2, LED3, LED4);

PinDetect Up(p16);
PinDetect Down(p17);
PinDetect Left(p5);
PinDetect Right(p15);
PinDetect ScreenSwitch(p14);

int y;
int mo;
int d;
int h;
int m;
int maxx = 128;
int maxy = 128;

Timer secondsT;

int selectedValue = 0;

// global sensor data saved
int selectDate = 0;
int sample_ftemp;
int sample_ctemp;
int sample_ktemp;
int sample_humid;

// conditions for screen
float lightLevel = 0;
int backColor;

int getmaxx() { return maxx; }

int getmaxy() { return maxy; }

const char *returnDay(int year, int month, int day) {
    // 4/26/23 is base date - Wednesday
    int baseyear = 23;
    int basemonth = 4;
    int baseday = 26;

    year = (year - baseday) * 365;
    month = month - basemonth;
    day = day - baseday;

    if (mo == 4 || mo == 6 || mo == 9 || mo == 11) {
        month = month * 30;
    } else if (mo == 2) {
        month = month * 28;
    } else {
        month = month * 31;
    }
    day = day + month + year;
    day = abs(day);
    day = day % 7;
    if (day == 0) {
        return "Wedn";
    }
    if (day == 1) {
        return "Thrus";
    }
    if (day == 2) {
        return "Fri";
    }
    if (day == 3) {
        return "Sat";
    }
    if (day == 4) {
        return "Sun";
    }
    if (day == 5) {
        return "Mon";
    }
    if (day == 6) {
        return "Tues";
    }
    return "Fun";
}

void headerSecUpdate() {
    string dayOfWeek = returnDay(y, mo, d);
    int secs = secondsT.read();
    uLCD.locate(0, 2);
    uLCD.printf("%d/%d/%d %s-%d:%d:%d\n", d, mo, y, dayOfWeek, h, m, secs);
}

void minPassed() {
    if (secondsT.read() >= 60) {
        secondsT.reset();
        m++;
        if (m == 60) {
            m = 0;
            h++;
        }
    }
}

int returnDayColor() {
    int red, green, blue;
    int totalC;
    if (h >= 12) {
        blue = h - 24;
    }

    blue = 19 * abs(blue);
    if (blue >= 255) {
        blue = 255;
    }
    red = blue / 2;
    green = blue / 2;
    red = red << 16;
    green = green << 8;
    totalC = red + green + blue;
    return totalC;
}

string toLower(string in) {
    for (int i = 0; i < in.length(); i++) {
        in[i] = tolower(in[i]);
    }
    return in;
}

void setHeader(bool clear, bool init) {
    if (clear) {
        uLCD.cls();
        backColor = returnDayColor();
        uLCD.filled_rectangle(0, 0, 150, 150, backColor);
    }

    uLCD.filled_rectangle(0, 0, 150, 17, BLACK);
    uLCD.filled_rectangle(0, 17, 150, 18, WHITE);
    uLCD.color(WHITE);
    uLCD.locate(0, 0);
    uLCD.printf("4180 Weather App\n");

    if (!init) {
        string dayOfWeek = returnDay(y, mo, d);
        int secs = secondsT.read();
        uLCD.printf("%d/%d/%d %s-%d:%d:%d\n", d, mo, y, dayOfWeek, h, m, secs);
    }
}

void secHand() {
    int r = 80, x = maxx / 2, y = maxy / 2, sec;
    float O;

    maxx = getmaxx();
    maxy = getmaxy();
    gettime(&t); /*getting the seconds in system clock */
    sec = t.ti_sec;
    O = sec * (PI / 30) -
        (PI /
         2); /* determining the angle of the line with respect to vertical */
    uLCD.color(0xFFFF00);
    uLCD.line(70, 70, x + r * cos(O), y + r * sin(O), RED);
}

void hrHand() {
    int r = 50, hr, min;
    int x, y;
    struct time t;
    float O;

    maxx = getmaxx();
    maxy = getmaxy();
    x = maxx / 2, y = maxy / 2;
    gettime(&t); /*getting the seconds in system clock */
    hr = t.ti_hour;
    min = t.ti_min;

    /* determining the angle of the line with respect to vertical */
    if (hr <= 12) O = (hr * (PI / 6) - (PI / 2)) + ((min / 12) * (PI / 30));
    if (hr > 12)
        O = ((hr - 12) * (PI / 6) - (PI / 2)) + ((min / 12) * (PI / 30));
    uLCD.color(BLUE);
    uLCD.line(70, 70, x + r * cos(O), y + r * sin(O), RED);
}

void minHand() {
    int r = 60, min;
    int x, y;
    float O;
    struct time t;
    maxx = getmaxx();
    maxy = getmaxy();
    x = maxx / 2;
    y = maxy / 2;
    gettime(&t); /*getting the seconds in system clock */
    min = t.ti_min;
    O = (min * (PI / 30) -
         (PI /
          2)); /* determining the angle of the line with respect to vertical */
    uLCD.color(RED);
    uLCD.line(70, 70, x + r * cos(O), y + r * sin(O), RED);
}

void clockLCD() {
    uLCD.circle(60, 70, 50, WHITE);
    uLCD.circle(60, 70, 48, BLACK);
    uLCD.circle(60, 70, 5, WHITE);
    while (1) {
        secHand();
        minHand();
        hrHand();
    }
}

void printAttitude(float ax, float ay, float az, float mx, float my, float mz) {
    float roll = atan2(ay, az);
    float pitch = atan2(-ax, sqrt(ay * ay + az * az));

    mx = -mx;
    float heading;

    if (my == 0.0)
        heading = (mx < 0.0) ? 180.0 : 0.0;
    else
        heading = atan2(mx, my) * 360.0 / (2.0 * PI);

    heading -= DECLINATION;

    if (heading > 180.0)
        heading = heading - 360.0;
    else if (heading < -180.0)
        heading = 360.0 + heading;
    else if (heading < 0.0)
        heading = 360.0 + heading;

    pitch *= 180.0 / PI;
    roll *= 180.0 / PI;

    uLCD.printf("Pitch: %f,    Roll: %f degress\n\r", pitch, roll);
    uLCD.printf("Magnetic Heading: %f degress\n\r", heading);
}

void generalDataScreen() {
    double alt, bar, temp;
    if (!IMU.begin()) {
        pc.printf("Failed to communicate with LSM9DS1.\n");
    }
    // imu.calibrate();
    while (1) {
        IMU.readTemp();
        IMU.readMag();
        IMU.readGyro();

        uLCD.baudrate(32000);
        uLCD.printf("%.3d  %.3d  %.3d\n", IMU.mx, IMU.my, IMU.mz);

        wait(.05);
        uLCD.cls();
    }

    // uLCD.printf("General Data\n");
}

void moonCycle() {
    setHeader(true, false);
    switch (d) {
        case 1:  // fat right
            uLCD.filled_circle(60, 70, 50, WHITE);
            uLCD.filled_circle(61, 70, 47, BLACK);
            uLCD.filled_circle(73, 70, 47, WHITE);
            break;
        case 2:  // full
            uLCD.filled_circle(60, 70, 50, WHITE);
            break;
        case 3:  // full
            uLCD.filled_circle(60, 70, 50, WHITE);
            break;
        case 4:  // fat left
            uLCD.filled_circle(70, 70, 50, WHITE);
            uLCD.filled_circle(69, 70, 47, BLACK);
            uLCD.filled_circle(57, 70, 47, WHITE);
            break;
        case 5:  // third q left
            uLCD.filled_circle(60, 70, 50, WHITE);
            uLCD.filled_rectangle(60, 18, 200, 200, BLACK);
            break;
        case 6:  // tiny left
            uLCD.filled_circle(60, 70, 50, WHITE);
            uLCD.filled_circle(77, 70, 49, BLACK);
            break;
        case 7:  // new moon
            uLCD.filled_circle(60, 70, 50, WHITE);
            uLCD.filled_circle(60, 70, 48, BLACK);
            break;
        case 8:  // new moon
            uLCD.filled_circle(60, 70, 50, WHITE);
            uLCD.filled_circle(60, 70, 48, BLACK);
            break;
        case 9:  // tiny right
            uLCD.filled_circle(65, 70, 50, WHITE);
            uLCD.filled_circle(52, 70, 49, BLACK);
            break;
        case 10:  // first q right
            uLCD.filled_circle(60, 70, 50, WHITE);
            uLCD.filled_rectangle(0, 18, 60, 200, BLACK);
            break;
        default:
            printf("not");
    }
}

void dayCycle() {
    setHeader(true, false);
    if (h > 7 && h < 18) {
        if (h == 7 || h == 17) {
            uLCD.filled_circle(65, 170, 50, 0xfdd835);
        }
        if (h == 8 || h == 16) {
            uLCD.filled_circle(65, 130, 50, 0xfdd835);
        }
        if (h == 9 || h == 15) {
            uLCD.filled_circle(65, 90, 50, 0xfdd835);
        }
        if (h == 10 || h == 14) {
            uLCD.filled_circle(65, 50, 50, 0xfdd835);
        }
        if (h == 11 || h == 13) {
            uLCD.filled_circle(65, 30, 50, 0xfdd835);
        }
        if (h == 12) {
            uLCD.filled_circle(65, 0, 50, 0xfdd835);
        }
        uLCD.filled_rectangle(0, 100, 200, 200, 0x90EE90);
    } else {
        if (h == 19 || h == 5) {
            uLCD.filled_circle(65, 150, 50, 0xfdd835);
        }
        if (h == 20 || h == 4) {
            uLCD.filled_circle(65, 110, 50, 0xfdd835);
        }
        if (h == 21 || h == 3) {
            uLCD.filled_circle(65, 80, 50, 0xfdd835);
        }
        if (h == 22 || h == 2) {
            uLCD.filled_circle(65, 50, 50, 0xfdd835);
        }
        if (h == 23 || h == 1) {
            uLCD.filled_circle(65, 30, 50, 0xfdd835);
        }
        if (h == 24) {
            uLCD.filled_circle(65, 0, 50, 0xfdd835);
        }
        uLCD.filled_rectangle(0, 100, 200, 200, 0x023020);
    }
    setHeader(false, false);
}

void realTimeBar() {
    setHeader(true, false);
    uLCD.color(WHITE);
    uLCD.locate(0, 3);
    uLCD.text_width(2);
    uLCD.text_height(2);
    uLCD.textbackground_color(backColor);
    uLCD.printf("x y z Lit");
    uLCD.locate(0, 3);

    uLCD.text_height(10);
    uLCD.printf("|  |  |   |");

    while (1) {
        uLCD.filled_rectangle(0, 75, 70, 80, WHITE);
        uLCD.cls();

        IMU.readTemp();
        IMU.readMag();
        IMU.readGyro();

        uLCD.text_width(1);
        uLCD.text_height(1);

        float inX = (IMU.mx / 42);
        float inY = (IMU.my / 42);
        float inZ = (IMU.mz / 42);
        uLCD.printf("%.3d   %.3d   %.3d\n", IMU.mx, IMU.my, IMU.mz);

        if (inX > 0) {
            inX = abs(inX - 80);
            uLCD.filled_rectangle(0, inX, 12, 80, GREEN);
        } else {
            inX = abs(inX) + 70;
            uLCD.filled_rectangle(0, 80, 12, inX, RED);
        }
        if (inY > 0) {
            inY = abs(inY - 30);
            uLCD.filled_rectangle(28, inY, 40, 80, GREEN);
        } else {
            inY = abs(inY) + 110;
            uLCD.filled_rectangle(28, 80, 40, inY, RED);
        }
        if (inZ > 0) {
            inZ = abs(inZ - 60);

            uLCD.filled_rectangle(55, inZ, 70, 80, GREEN);
        }

        else {
            inZ = abs(inZ) + 90;
            uLCD.filled_rectangle(55, 80, 70, inZ, RED);
        }
    }
}

void tempChart() {
    uLCD.locate(0, 3);
    uLCD.text_width(2);
    uLCD.text_height(2);
    uLCD.textbackground_color(backColor);
    uLCD.printf("CurrTemp:");
    uLCD.locate(0, 3);
    uLCD.printf("%.2d", sample_ftemp);
    uLCD.text_width(1);
    uLCD.text_height(1);
    uLCD.locate(0, 9);
    uLCD.color(WHITE);
    uLCD.printf("100 85 70 55 40\n");
    uLCD.text_height(4);
    uLCD.printf(" |  |  |  |  |");

    uLCD.filled_circle(105, 105, 18, WHITE);
    uLCD.filled_rectangle(15, 95, 110, 115, WHITE);
    uLCD.filled_circle(15, 105, 10, WHITE);

    uLCD.filled_circle(15, 105, 5, BLACK);
    uLCD.filled_rectangle(15, 103, 110, 107, BLACK);

    uLCD.filled_circle(105, 105, 15, RED);
    // highest value is 15
    // 40-100 -> 15-110 pixel
    int offset = sample_ftemp;
    for (int i = 40; i < 100; i++) {
        offset = i;
        offset = offset * 1.5;
        offset = (int)offset - 170;
        offset = abs(offset);
        if (offset >= 100) {
            uLCD.filled_circle(15, 105, 8, RED);
        }
        uLCD.filled_rectangle(offset, 97, 110, 113, RED);
    }
}

void blackout(int line, int color1, int color2) {
    uLCD.color(color1);
    uLCD.locate(0, line);
    uLCD.printf("oooooooooooooooooo");
    uLCD.color(color2);
}

void dateIncrement() {
    switch (selectedValue) {
        case 0:
            blackout(11, RED, GREEN);
            uLCD.locate(0, 11);
            // uLCD.printf("(%d/%d/%d)\n", baseDates->years,
            // baseDates->months,baseDates->days);
            y++;
            uLCD.printf("Date: (%d/%d/%d)\n", d, mo, y);
            break;

        case 1:
            blackout(11, RED, GREEN);
            uLCD.locate(0, 11);
            if (mo < 12) {
                if (d >= 28) {
                    d = 28;
                }
                mo++;
            }
            uLCD.printf("Date: (%d/%d/%d)\n", d, mo, y);
            break;

        case 2:
            blackout(11, RED, GREEN);
            uLCD.locate(0, 11);
            if (d < 31) {
                if (mo == 4 || mo == 6 || mo == 9 || mo == 11) {
                    if (d < 30) {
                        d++;
                    }
                } else if (mo == 2) {
                    if (d < 28) {
                        d++;
                    }
                } else {
                    d++;
                }
            }
            uLCD.printf("Date: (%d/%d/%d)\n", d, mo, y);
            break;

        case 3:
            blackout(12, RED, GREEN);
            uLCD.locate(0, 12);
            if (h < 24) {
                h++;
            }
            uLCD.printf("Hour: %d\n", h);
            break;

        case 4:
            blackout(13, RED, GREEN);
            uLCD.locate(0, 13);
            if (m < 60) {
                m++;
            }
            uLCD.printf("Min: %d\n", m);
            break;

        default:
            printf("nop");
    }
    printf("nop");
}
void dateDeinc() {
    switch (selectedValue) {
        case 0:
            blackout(11, RED, GREEN);
            uLCD.locate(0, 11);
            if (y > 23) {
                y--;
            }
            uLCD.printf("Date: (%d/%d/%d)\n", d, mo, y);
            break;

        case 1:
            blackout(11, RED, GREEN);
            uLCD.locate(0, 11);
            if (mo > 1) {
                if (d >= 28) {
                    d = 28;
                }
                mo--;
            }
            uLCD.printf("Date: (%d/%d/%d)\n", d, mo, y);

            break;
        case 2:
            blackout(11, RED, GREEN);
            uLCD.locate(0, 11);
            if (d > 1) {
                d--;
            }
            uLCD.printf("Date: (%d/%d/%d)\n", d, mo, y);
            break;

        case 3:
            blackout(12, RED, GREEN);
            uLCD.locate(0, 12);
            if (h > 1) {
                h--;
            }
            uLCD.printf("Hour: %d\n", h);
            break;

        case 4:
            blackout(13, RED, GREEN);
            uLCD.locate(0, 13);
            if (m > 1) {
                m--;
            }
            uLCD.printf("Min: %d\n", m);
            break;

        default:
            printf("nop");
    }
    printf("nop");
}

void dateSet() {
    if (selectedValue < 6) {
        selectedValue++;
    }
    if (selectedValue == 3) {
        uLCD.locate(0, 12);
        uLCD.printf("Hour: 1");
        blackout(14, BLACK, GREEN);
        blackout(13, BLACK, GREEN);
    }
    if (selectedValue == 4) {
        uLCD.locate(0, 13);
        uLCD.printf("Mins: 0");
        blackout(14, BLACK, GREEN);
    }
    if (selectedValue == 5) {
        blackout(14, RED, GREEN);
        uLCD.locate(0, 14);
        uLCD.printf("Values Correct?");
    }
    if (selectedValue == 6) {
        secondsT.start();
        uLCD.color(WHITE);
    }
}

void dateDeSet() {
    if (selectedValue > 0 && selectedValue < 6) {
        selectedValue--;
    }
}

void initDate() {
    setHeader(false, true);
    uLCD.locate(0, 3);
    uLCD.color(GREEN);
    uLCD.printf("Set date to \nuse application");
    y = 23;
    mo = 1;
    d = 1;
    h = 1;
    m = 0;

    uLCD.printf(
        "\n\nUp to incrament\nDown to decrement\nRight to enter\nLeft to "
        "cancel\n");
    uLCD.printf("\nDate: ");
}

void ScreenSelect() {
    char bnum = 0;
    char bhit = 0;
    bool realease = true;
    bool after = false;
    while (blue.readable()) {
        if (blue.getc() == '!') {
            if (blue.getc() == 'B') {  // button data packet
                bnum = blue.getc();    // button number
                bhit = blue.getc();    // 1=hit, 0=release
                if (blue.getc() ==
                    char(~('!' + 'B' + bnum + bhit))) {  // checksum OK?
                    myled = bnum -
                            '0';  // current button number will appear on LEDs
                    switch (bnum) {
                        case '1':
                            // number button 1 for temp
                            if (bhit == '1') {
                                if (realease && selectedValue >= 6) {
                                    realease = false;
                                    myled = 15 - '0';
                                    generalDataScreen();
                                    wait(2);
                                }

                            } else {
                                realease = true;
                                myled = bnum - '0';
                            }
                            break;
                        case '2':  // number button 2
                            if (bhit == '1') {
                                if (realease && selectedValue >= 6) {
                                    realease = false;
                                    moonCycle();
                                    myled = 15 - '0';
                                    wait(2);
                                }
                            } else {
                                realease = true;
                                myled = bnum - '0';
                            }
                            break;
                        case '3':  // number button 3
                            if (bhit == '1') {
                                if (realease && selectedValue >= 6) {
                                    realease = false;
                                    myled = 15 - '0';
                                    dayCycle();
                                    wait(2);
                                }
                            } else {
                                realease = true;
                                myled = bnum - '0';
                            }
                            break;
                        case '4':  // number button 4
                            if (bhit == '1') {
                                if (realease && selectedValue >= 6) {
                                    realease = false;
                                    myled = 15 - '0';
                                    tempChart();
                                    wait(2);
                                }
                                // add hit code here
                            } else {
                                realease = true;

                                myled = bnum - '0';
                            }
                            break;
                        case '5':
                            // button 5 up arrow
                            if (bhit == '1') {
                                myled = 15 - '0';
                                if (selectedValue >= 6) {
                                } else {
                                    dateIncrement();
                                }

                                wait(.2);

                            } else {
                                myled = '0';
                            }
                            break;
                        case '6':  // button 6 down arrow
                            if (bhit == '1') {
                                myled = 15 - '0';
                                if (selectedValue >= 6) {
                                } else {
                                    dateDeinc();
                                }

                                wait(.2);

                            } else {
                                myled = '0';
                            }
                            break;
                        case '7':  // button 7 left arrow
                            if (bhit == '1') {
                                myled = 15 - '0';
                                if (selectedValue >= 6) {
                                } else {
                                    dateDeSet();
                                }
                                wait(.2);

                            } else {
                                myled = '0';
                            }
                            break;
                        case '8':  // button 8 right arrow
                            if (bhit == '1') {
                                myled = 15 - '0';
                                if (selectedValue >= 6) {
                                } else {
                                    dateSet();
                                }
                                wait(.2);

                            } else {
                                myled = '0';
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
        }
    }
}

int main() {
    IMU.begin();
    IMU.calibrate();
    realTimeBar();
    blue.attach(&ScreenSelect, Serial::RxIrq);
}
